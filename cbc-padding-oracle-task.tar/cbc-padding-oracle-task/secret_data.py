encryption_key = b'BBB<redacted>BBB'
secret = '<redacted>'
